\
    #!/usr/bin/env python3
    """
    recsys_pipeline.py
    Simple, self-contained recommender pipeline helper.
    This script demonstrates preprocessing and provides functions for:
      - item-based collaborative filtering (neighbourhood)
      - content-based TF-IDF recommendations
    It does NOT run heavy training automatically; it provides a quick demo when executed.
    Requirements: pandas, numpy, scipy, scikit-learn
    """
    import os
    import numpy as np
    import pandas as pd
    from scipy.sparse import csr_matrix
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    import heapq

    def load_data(base_path='.'):
        books = pd.read_csv(os.path.join(base_path, "Books.csv"))
        ratings = pd.read_csv(os.path.join(base_path, "Ratings.csv"))
        users = pd.read_csv(os.path.join(base_path, "Users.csv"))
        return books, ratings, users

    def filter_active(ratings, min_user_ratings=20, min_item_ratings=20):
        pos = ratings[ratings['Book-Rating'] > 0].copy()
        user_counts = pos['User-ID'].value_counts()
        item_counts = pos['ISBN'].value_counts()
        active_users = user_counts[user_counts >= min_user_ratings].index
        active_items = item_counts[item_counts >= min_item_ratings].index
        filtered = pos[pos['User-ID'].isin(active_users) & pos['ISBN'].isin(active_items)].copy()
        return filtered

    def leave_one_out(df, seed=42):
        np.random.seed(seed)
        train_list, test_list = [], []
        for user, user_df in df.groupby('User-ID'):
            if len(user_df) < 2:
                train_list.append(user_df); continue
            test_idx = np.random.choice(user_df.index, size=1, replace=False)
            test_list.append(user_df.loc[test_idx]); train_list.append(user_df.drop(test_idx))
        return pd.concat(train_list).reset_index(drop=True), pd.concat(test_list).reset_index(drop=True)

    def build_interaction(train):
        user_ids = train['User-ID'].unique()
        item_ids = train['ISBN'].unique()
        user_to_idx = {u:i for i,u in enumerate(user_ids)}
        item_to_idx = {i:j for j,i in enumerate(item_ids)}
        rows = train['User-ID'].map(user_to_idx); cols = train['ISBN'].map(item_to_idx)
        data = np.ones(len(train), dtype=np.float32)
        interaction = csr_matrix((data, (rows, cols)), shape=(len(user_ids), len(item_ids)))
        return interaction, user_ids, item_ids, user_to_idx, item_to_idx

    def train_item_similarity(interaction):
        # Compute cosine similarity between items (items x users)
        item_user = interaction.T.tocsr()
        item_user_dense = item_user.toarray().astype(np.float32)
        sim = cosine_similarity(item_user_dense)
        return sim

    def train_content(books_df, item_ids, max_features=5000):
        books_sub = books_df[books_df['ISBN'].isin(item_ids)].copy()
        books_sub['content'] = (books_sub['Book-Title'].fillna('') + ' ' +
                                books_sub['Book-Author'].fillna('') + ' ' +
                                books_sub['Publisher'].fillna('')).str.lower()
        tf = TfidfVectorizer(max_features=max_features, stop_words='english')
        tfidf_matrix = tf.fit_transform(books_sub['content'])
        return tfidf_matrix, books_sub

    def recommend_item_based(interaction, item_sim, user_to_idx, item_ids, user_id, N=10):
        if user_id not in user_to_idx: return []
        uidx = user_to_idx[user_id]
        user_row = interaction[uidx].toarray().ravel()
        seen = set(np.where(user_row > 0)[0])
        scores = {}
        for i in seen:
            sims = item_sim[i]
            for j, s in enumerate(sims):
                if j in seen: continue
                scores[j] = scores.get(j, 0.0) + s
        top = heapq.nlargest(N, scores.items(), key=lambda x: x[1])
        return [item_ids[idx] for idx,_ in top]

    def recommend_content_fast(interaction, tfidf_matrix, books_sub, item_ids, isbn_to_content_idx, contentidx_to_trainidx, user_to_idx, user_id, N=10):
        if user_id not in user_to_idx: return []
        uidx = user_to_idx[user_id]
        user_row = interaction[uidx].toarray().ravel()
        seen = np.where(user_row > 0)[0]
        content_idxs = [isbn_to_content_idx[item_ids[i]] for i in seen if item_ids[i] in isbn_to_content_idx]
        if len(content_idxs) == 0: return []
        user_profile = tfidf_matrix[content_idxs].mean(axis=0)
        sims = cosine_similarity(user_profile, tfidf_matrix).ravel()
        scored = []
        for cidx, sc in enumerate(sims):
            if cidx in contentidx_to_trainidx:
                train_idx = contentidx_to_trainidx[cidx]
                if train_idx in seen: continue
                scored.append((train_idx, float(sc)))
        top = heapq.nlargest(N, scored, key=lambda x: x[1])
        return [item_ids[idx] for idx,_ in top]

    def main_demo(base_path='.'):
        print("Loading data from:", base_path)
        books, ratings, users = load_data(base_path)
        print("Raw counts: books={}, ratings={}, users={}".format(len(books), len(ratings), len(users)))
        filtered = filter_active(ratings)
        print("Filtered interactions (users>=20, items>=20):", len(filtered))
        if len(filtered) == 0:
            print("Not enough data after filtering. Exiting demo.")
            return
        train, test = leave_one_out(filtered)
        interaction, user_ids, item_ids, user_to_idx, item_to_idx = build_interaction(train)
        print("Interaction matrix:", interaction.shape)
        # Compute item similarity for a small demo (may be slow on large matrices)
        print("Computing item-item similarity (may take a while)...")
        item_sim = train_item_similarity(interaction)
        print("Item similarity shape:", item_sim.shape)
        # Prepare content matrix
        tfidf_matrix, books_sub = train_content(books, item_ids)
        isbn_to_content_idx = {isbn: i for i,isbn in enumerate(list(books_sub['ISBN']))}
        contentidx_to_trainidx = {}
        for train_idx,isbn in enumerate(item_ids):
            if isbn in isbn_to_content_idx:
                contentidx_to_trainidx[isbn_to_content_idx[isbn]] = train_idx
        # Pick a sample user and show recommendations
        sample_user = train['User-ID'].iloc[0]
        print("\\nSample user:", sample_user)
        recs_item = recommend_item_based(interaction, item_sim, user_to_idx, item_ids, sample_user, N=5)
        recs_content = recommend_content_fast(interaction, tfidf_matrix, books_sub, item_ids, isbn_to_content_idx, contentidx_to_trainidx, user_to_idx, sample_user, N=5)
        print("Item-based recs (5):", recs_item)
        print("Content-based recs (5):", recs_content)
        print("\\nDemo finished. To run full evaluation, import functions from this script in a notebook or extend main_demo.")

    if __name__ == "__main__":
        demo_base = os.path.dirname(__file__) if '__file__' in globals() else '.'
        main_demo(demo_base)
